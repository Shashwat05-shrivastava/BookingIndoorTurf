import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTurfComponent } from './components/add-turf/add-turf.component';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { ShowBookedTurfsComponent } from './components/admin/show-booked-turfs/show-booked-turfs.component';
import { UsersListComponent } from './components/admin/users-list/users-list.component';
import { WelcomeComponent } from './components/admin/welcome/welcome.component';
import { BookedTurfsComponent } from './components/booked-turfs/booked-turfs.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RegisterTurfComponent } from './components/register-turf/register-turf.component';
import { SignupComponent } from './components/signup/signup.component';
import { TurfListComponent } from './components/turf-list/turf-list.component';
import { UpdateBookedTurfComponent } from './components/update-booked-turf/update-booked-turf.component';
import { UpdateTurfComponent } from './components/update-turf/update-turf.component';
import { UserTurfsListComponent } from './components/user-turfs-list/user-turfs-list.component';
import { UserDashboardComponent } from './components/user/user-dashboard/user-dashboard.component';
import { WelcomeUserComponent } from './components/user/welcome-user/welcome-user.component';
import { AdminGuard } from './services/admin.guard';
import { NormalGuard } from './services/normal.guard';

const routes: Routes = [
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'signup',component:SignupComponent,pathMatch:'full'},
  {path:'login',component:LoginComponent,pathMatch:"full"},
  {path:'admin',component:DashboardComponent,canActivate:[AdminGuard],
  children:[
    {path:'',component:WelcomeComponent},
    {path:'profile',component:ProfileComponent},
    {path:'turf-list',component:TurfListComponent},
    {path:'add-turf',component:AddTurfComponent},
    {path:'turf-list/:tId',component:UpdateTurfComponent},
    {path:'show-booked-turfs',component:ShowBookedTurfsComponent},
    {path:'users-list',component:UsersListComponent}
  ]
},
  {path:'user-dashboard',component:UserDashboardComponent,canActivate:[NormalGuard],
  children:[
    {path:'',component:WelcomeUserComponent},
    {path:'profile',component:ProfileComponent},
    {path:'user-turfs-list',component:UserTurfsListComponent},
    {path:'register-turf',component:RegisterTurfComponent},
    {path:'bookedTurfs',component:BookedTurfsComponent},
    {path:'update-booked-turf/:tId',component:UpdateBookedTurfComponent},
  ]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
