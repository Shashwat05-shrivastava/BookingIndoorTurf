import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { SignupComponent } from './components/signup/signup.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import {MatCardModule} from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './components/user/user-dashboard/user-dashboard.component';
import { authInterceptorProviders } from './services/auth.interceptor';
import { ProfileComponent } from './components/profile/profile.component';
import { SidebarComponent } from './components/admin/sidebar/sidebar.component';
import { WelcomeComponent } from './components/admin/welcome/welcome.component';
import { UserSidebarComponent } from './components/user/user-sidebar/user-sidebar.component';
import { WelcomeUserComponent } from './components/user/welcome-user/welcome-user.component';
import { TurfListComponent } from './components/turf-list/turf-list.component';
import { AddTurfComponent } from './components/add-turf/add-turf.component';
import { UpdateTurfComponent } from './components/update-turf/update-turf.component';
import { UserTurfsListComponent } from './components/user-turfs-list/user-turfs-list.component';
import { RegisterTurfComponent } from './components/register-turf/register-turf.component';
import { BookedTurfsComponent } from './components/booked-turfs/booked-turfs.component';
import { UpdateBookedTurfComponent } from './components/update-booked-turf/update-booked-turf.component';
import { ShowBookedTurfsComponent } from './components/admin/show-booked-turfs/show-booked-turfs.component';
import { UsersListComponent } from './components/admin/users-list/users-list.component';
import { UpdateUserComponent } from './components/update-user/update-user.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    HomeComponent,
    NavbarComponent,
    DashboardComponent,
    UserDashboardComponent,
    ProfileComponent,
    SidebarComponent,
    WelcomeComponent,
    UserSidebarComponent,
    WelcomeUserComponent,
    TurfListComponent,
    AddTurfComponent,
    UpdateTurfComponent,
    UserTurfsListComponent,
    RegisterTurfComponent,
    BookedTurfsComponent,
    UpdateBookedTurfComponent,
    ShowBookedTurfsComponent,
    UsersListComponent,
    UpdateUserComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule,
    MatListModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
