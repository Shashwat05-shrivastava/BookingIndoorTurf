import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterTurfComponent } from './register-turf.component';

describe('RegisterTurfComponent', () => {
  let component: RegisterTurfComponent;
  let fixture: ComponentFixture<RegisterTurfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterTurfComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterTurfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
