import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RegisterTurfServiceService } from 'src/app/services/register-turf-service.service';

@Component({
  selector: 'app-register-turf',
  templateUrl: './register-turf.component.html',
  styleUrls: ['./register-turf.component.css']
})
export class RegisterTurfComponent implements OnInit {

  registerTurf={
    tId:'',
    turfName:'',
    userId:'',
    emailId:'',
    phone:''
  }

  constructor(private _snack:MatSnackBar,private _rTurf:RegisterTurfServiceService) { }

  ngOnInit(): void {
    // TODO document why this method 'ngOnInit' is empty
  
  }

  formSubmit(){
    if(this.registerTurf.tId==null){
      this._snack.open("Id Required",'',{
        duration:3000
      })
      return;
    }

    this._rTurf.addTurf(this.registerTurf).subscribe(
      (data)=>{
        
        this.registerTurf.tId='',
        this.registerTurf.turfName='',
        this.registerTurf.userId='',
        this.registerTurf.emailId='',
        this.registerTurf.phone='',

        alert("Success");
      },
      (error)=>{
        alert("Failed");
      }
    );
  }

}
