import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTurfComponent } from './update-turf.component';

describe('UpdateTurfComponent', () => {
  let component: UpdateTurfComponent;
  let fixture: ComponentFixture<UpdateTurfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateTurfComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateTurfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
