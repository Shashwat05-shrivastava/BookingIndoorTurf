import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TurfService } from 'src/app/services/turf.service';

@Component({
  selector: 'app-update-turf',
  templateUrl: './update-turf.component.html',
  styleUrls: ['./update-turf.component.css']
})
export class UpdateTurfComponent implements OnInit {

  constructor(private _route:ActivatedRoute,private _turf:TurfService,private _router: Router) { }

  tId=0;
  Turf;

  ngOnInit(): void {
    this.tId=this._route.snapshot.params['tId'];
    //alert(this.tId);
    this._turf.getTurf(this.tId).subscribe(
      (data)=>{
        this.Turf=data;
        console.log(this.Turf);
      },
      (error)=>{
        console.log(error);
      }
    )
  }

  //Update form Submit()
  public updateData(){
    //alert('tst');

    this._turf.updateTurf(this.Turf).subscribe((data)=>{
      alert("Updated Successfully !!");
    },(error)=>{
      alert("Error occured !!");
      console.log(error);
    });
  }
}
