import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TurfService } from 'src/app/services/turf.service';

@Component({
  selector: 'app-add-turf',
  templateUrl: './add-turf.component.html',
  styleUrls: ['./add-turf.component.css']
})
export class AddTurfComponent implements OnInit {

  turf={
    tId:'',
    turfName:'',
    turfPrice:''
  }
  constructor(private _turf:TurfService,private _snack:MatSnackBar) { }

  ngOnInit(): void {
  }

  formSubmit(){
    if(this.turf.tId==null){
      this._snack.open("Id Required",'',{
        duration:3000
      })
      return;
    }

    this._turf.addTurf(this.turf).subscribe(
      (data)=>{
        
        this.turf.tId='',
        this.turf.turfName='',
        this.turf.turfPrice=''

        alert("Success");
      },
      (error)=>{
        alert("Failed");
      }
    );
  }

}
