import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateBookedTurfComponent } from './update-booked-turf.component';

describe('UpdateBookedTurfComponent', () => {
  let component: UpdateBookedTurfComponent;
  let fixture: ComponentFixture<UpdateBookedTurfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateBookedTurfComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateBookedTurfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
