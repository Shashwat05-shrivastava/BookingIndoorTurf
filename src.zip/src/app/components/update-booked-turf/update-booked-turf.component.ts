import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RegisterTurfServiceService } from 'src/app/services/register-turf-service.service';
import { TurfService } from 'src/app/services/turf.service';

@Component({
  selector: 'app-update-booked-turf',
  templateUrl: './update-booked-turf.component.html',
  styleUrls: ['./update-booked-turf.component.css']
})
export class UpdateBookedTurfComponent implements OnInit {

  constructor(private _route:ActivatedRoute,private _rTurf:RegisterTurfServiceService,private _router: Router) { }
  tId=0;
  registerTurf;

  ngOnInit(): void {
    this.tId=this._route.snapshot.params['tId'];
    //alert(this.tId);
    this._rTurf.getTurf(this.tId).subscribe(
      (data)=>{
        this.registerTurf=data;
        console.log(this.registerTurf);
      },
      (error)=>{
        console.log(error);
      }
    )
  }

  public updateData(){
    //alert('tst');

    this._rTurf.updateTurf(this.registerTurf).subscribe((data)=>{
      alert("Updated Successfully !!");
    },(error)=>{
      alert("Error occured !!");
      console.log(error);
    });
  }

}
