import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  users=[]
  constructor(private user:UserService) { }

  ngOnInit(): void {
    this.user.users().subscribe((data:any)=>{
      this.users=data;
      console.log(this.users);
    },(error)=>{
      console.log(error);
      alert("Error !!");
    });
  }
}
