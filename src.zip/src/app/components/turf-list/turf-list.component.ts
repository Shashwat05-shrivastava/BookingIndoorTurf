import { Component, OnInit } from '@angular/core';
import { TurfService } from 'src/app/services/turf.service';

@Component({
  selector: 'app-turf-list',
  templateUrl: './turf-list.component.html',
  styleUrls: ['./turf-list.component.css']
})
export class TurfListComponent implements OnInit {

  turfs=[ ]
  constructor(private turf:TurfService) { }

  ngOnInit(): void {
    this.turf.turfs().subscribe((data:any)=>{
      this.turfs=data;
      console.log(this.turfs);
    },(error)=>{
      console.log(error);
      alert("Error !!");
    });
  }

  deleteTurf(tId){
    this.turf.deleteTurf(tId).subscribe(
      (data)=>{
        this.turfs=this.turfs.filter((turf)=>turf[tId] != tId)
        alert("Deleted successFully !!");
      },
      (error)=>{
        alert("Deletion Failed!");
      }
    );
  }
}
