import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private userService:UserService,private snackbar:MatSnackBar,private router:Router) { }

  public user={
    username:'',
    password:'',
    firstName:'',
    LastName:'',
    email:'',
    phone:'',
  }

  ngOnInit(): void {
    // TODO document why this method 'ngOnInit' is empty
  
  }
  formSubmit(){
    if(this.user.username ==''|| this.user.username == null){
      this.snackbar.open('Something went wrong', '', {
        duration: 3000
      });
      return ;
    }
    
    this.userService.addUser(this.user).subscribe((data)=>{
      console.log(data);
      
      this.snackbar.open('Successfull Registration', '', {
        duration: 3000
      });
      
    },(error)=>{
      console.log(error);
      
      this.snackbar.open('Something went wrong', '', {
        duration: 3000
      });
    })
  }
}
