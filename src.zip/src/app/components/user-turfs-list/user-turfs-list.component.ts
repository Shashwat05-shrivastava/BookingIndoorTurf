import { Component, OnInit } from '@angular/core';
import { TurfService } from 'src/app/services/turf.service';

@Component({
  selector: 'app-user-turfs-list',
  templateUrl: './user-turfs-list.component.html',
  styleUrls: ['./user-turfs-list.component.css']
})
export class UserTurfsListComponent implements OnInit {

  turfs=[ ]
  constructor(private turf:TurfService) { }

  ngOnInit(): void {
    this.turf.turfs().subscribe((data:any)=>{
      this.turfs=data;
      console.log(this.turfs);
    },(error)=>{
      console.log(error);
      alert("Error !!");
    });
  }

}
