import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTurfsListComponent } from './user-turfs-list.component';

describe('UserTurfsListComponent', () => {
  let component: UserTurfsListComponent;
  let fixture: ComponentFixture<UserTurfsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserTurfsListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserTurfsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
