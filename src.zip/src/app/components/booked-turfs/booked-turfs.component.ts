import { Component, OnInit } from '@angular/core';
import { RegisterTurfServiceService } from 'src/app/services/register-turf-service.service';

@Component({
  selector: 'app-booked-turfs',
  templateUrl: './booked-turfs.component.html',
  styleUrls: ['./booked-turfs.component.css']
})
export class BookedTurfsComponent implements OnInit {

  registeredTurfs=[ ]
  constructor(private _rTurf:RegisterTurfServiceService) { }

  ngOnInit(): void {
    this._rTurf.registeredTurfs().subscribe((data:any)=>{
      this.registeredTurfs=data;
      console.log(this.registeredTurfs);
    },(error)=>{
      console.log(error);
      alert("Error !!");
    });
  }

  deleteRegisteredTurf(tId){
    this._rTurf.deleteTurf(tId).subscribe(
      (data)=>{
        this.registeredTurfs=this.registeredTurfs.filter((turf)=>turf.tId != tId)
        alert("Deleted successFully !!");
      },
      (error)=>{
        alert("Deletion Failed!");
      }
    );
  }

}
