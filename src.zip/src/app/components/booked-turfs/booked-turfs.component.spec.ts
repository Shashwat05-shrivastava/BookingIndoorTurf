import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookedTurfsComponent } from './booked-turfs.component';

describe('BookedTurfsComponent', () => {
  let component: BookedTurfsComponent;
  let fixture: ComponentFixture<BookedTurfsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookedTurfsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookedTurfsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
