import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class RegisterTurfServiceService {

  constructor(private http:HttpClient) { }

  //load all the turfs
  public registeredTurfs(){
    return this.http.get(`${baseUrl}/registerturf/`);
  }

   //add new Turf
   public addTurf(rTurf){
    return this.http.post(`${baseUrl}/registerturf/`,rTurf);
  }

  //delete Turf
  public deleteTurf(tId){
    return this.http.delete(`${baseUrl}/registerturf/${tId}`);
  }

  //get the single turf data
  public getTurf(tId){
    return this.http.get(`${baseUrl}/registerturf/${tId}`);
  }

  //Update Turf
  public updateTurf(rTurf){
    return this.http.put(`${baseUrl}/registerturf/`,rTurf);
  }
}
