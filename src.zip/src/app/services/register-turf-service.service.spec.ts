import { TestBed } from '@angular/core/testing';

import { RegisterTurfServiceService } from './register-turf-service.service';

describe('RegisterTurfServiceService', () => {
  let service: RegisterTurfServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RegisterTurfServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
