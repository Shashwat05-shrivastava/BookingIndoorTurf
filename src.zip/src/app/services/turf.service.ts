import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class TurfService {
  constructor(private http:HttpClient) { }

  //load all the turfs
  public turfs(){
    return this.http.get(`${baseUrl}/turf/`);
  }

  //add new Turf
  public addTurf(turf){
    return this.http.post(`${baseUrl}/turf/`,turf);
  }

  //delete Turf
  public deleteTurf(tId){
    return this.http.delete(`${baseUrl}/turf/${tId}`);
  }

  //get the single turf data
  public getTurf(tId){
    return this.http.get(`${baseUrl}/turf/${tId}`);
  }

  //Update Turf
  public updateTurf(turf){
    return this.http.put(`${baseUrl}/turf/`,turf);
  }
}
